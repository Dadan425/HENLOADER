/*
 * Copyright (C) 2021-2024 Andy Nguyen
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 */

package org.bdj.api;

public final class Int16Array extends Buffer {
  public Int16Array(int length) {
    super(length * Int16.SIZE);
  }

  public short get(int index) {
    return getShort(index * Int16.SIZE);
  }

  public void set(int index, short value) {
    putShort(index * Int16.SIZE, value);
  }
}
