/*
 * Copyright (C) 2021-2024 Andy Nguyen
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 */

package org.bdj.api;

public class Text extends Buffer {
  private final String text;

  public Text(String text) {
    super(text.length() + 1);
    this.text = text;
    api.strcpy(address(), text);
  }

  public String toString() {
    return text;
  }
}
